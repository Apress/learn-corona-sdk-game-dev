application = {

  content = {

    -- Frame rate.
    fps = 30,

    -- Size of screen graphics are targeted to.
    width = 480,
    height = 800,

    -- How to stretch graphics on a larger screen.
    scale = "letterbox"

  }

}
